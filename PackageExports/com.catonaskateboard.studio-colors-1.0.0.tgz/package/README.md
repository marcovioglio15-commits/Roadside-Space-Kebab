# Studio Colors

Open **Tools > Studio Colors**, or select folders and use **Assets > Set Folder Color...**.

Folder rules use asset GUIDs and are stored in `ProjectSettings/StudioColors.asset`. Explicit overrides survive moves and renames. Child folders inherit dynamically; **No color** blocks inheritance and **Reset** removes an override. Undo persists to the settings file.

Register custom UI Toolkit labels or buttons with `ToolColors.Register(element, "Tool.Control")`. Their context menu exposes persistent text/background colors. IMGUI consumers can cache `ToolColors.CreateStyle` and rebuild it on `ColorSettings.Changed`.

Create a **Studio/Color Palette** asset for reusable runtime tokens. `ColorPalette.Apply` styles an existing UI Toolkit element; `PaletteGraphic` colors a preauthored uGUI/TMP Graphic without a frame loop. These are opt-in APIs, not a global Unity editor skin replacement.

This package also supplies the compact `StudioWindow` draft workspace used by Audio Studio and Menu Studio: wrapping tabs, a scrolling form, fixed Apply/Discard actions, Undo and concurrent-source protection. Drafts remain hidden and unsaved but editable.

Install by copying this directory into `Packages`, or selecting its `package.json` in Package Manager's **Install package from disk**. Install this package before Audio Studio/Menu Studio. See `SOURCES.md` for provenance.
