# Sources and provenance

The C# files in this package were newly written for this task. Existing project tools were inspected as functional references; their implementations were not copied. No third-party library implementation, native binary, shader, font, sprite, bank or audio file is redistributed here.

Unity and, where applicable, FMOD remain separately installed dependencies with their own terms. Referencing a public API does not transfer that dependency's implementation into this package. No ownership or license is asserted over third-party dependencies.

## Local functional references

- OFF BEAT DIVERPUNK: `Assets/Scripts/Utils/Editor/CustomFolderTool/ColoredFoldersEditor.cs`, `ColoredFolderInit.cs`, `ColoredFolderAutoApplyPostprocessor.cs`: folder selection, tint modes and inheritance behavior.
- OFF BEAT DIVERPUNK: `Assets/Scripts/Editor/Core/ManagementTool/Color/`: opt-in custom tool coloring.
- Roadside-Space-Kebab: `Packages/com.catonaskateboard.player-studio/Editor/Window/`: compact workspace organization, detached proposals and fixed action footer.

## Official API references

- [Unity custom packages](https://docs.unity3d.com/6000.0/Documentation/Manual/CustomPackages.html)
- [Unity HideFlags](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/HideFlags.html)
- [Unity HideAndDontSave](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/HideFlags.HideAndDontSave.html)
- Installed Unity 6000.6.0f1 assemblies: API signatures used for compilation.

The folder database was redesigned around GUID records; no legacy data migration or original project configuration is included.
