# Audio Studio

Requires **Studio Colors**. Open **Tools > Audio Studio**, create a preset and choose a Studio `.fspro` or a built-bank directory in Setup. Apply commits the detached proposal; Discard reloads the source.

**Catalog > Load catalog** reads Studio metadata directly, including nested folders, event GUIDs and assigned banks. Search, copy paths, create project-defined bindings or assign an event to an existing binding/music context. Presets start with no gameplay IDs or default event paths.

For bank catalogs and auditioning, install the official **FMOD for Unity** integration separately, build banks in Studio, Apply the connection and use **Connect FMOD / Refresh banks**. Matching built events add 2D/3D information and preview parameters. The optional adapter uses public integration APIs through editor-only reflection. No FMOD SDK source, native binary or audio content is bundled.

Tabs expose event metadata, volume/pitch, optional 3D distance overrides, single-instance requests, parameter values, per-event rate caps, playback defaults, bus routing and named music contexts with crossfade settings. Validation reports invalid values without clamping them.

These are authoring assets. Runtime playback, rate-limit enforcement, voice ownership, bus control, music state selection and gameplay dispatch belong to each consuming project's adapter. Catalog auditioning is an editor preview, not that runtime adapter. No ECS/DOTS dependencies are included.

Install Studio Colors first, then install this `package.json` from disk, copy this directory under `Packages`, or install the exported tarball. Connection paths and presets remain project-owned. See `SOURCES.md`.
