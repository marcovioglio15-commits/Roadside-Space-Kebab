# Sources and provenance

The C# files in this package were newly written for this task. Existing project tools were inspected as functional references; their implementations were not copied. No third-party library implementation, native binary, shader, font, sprite, bank or audio file is redistributed here.

Unity and, where applicable, FMOD remain separately installed dependencies with their own terms. Referencing a public API does not transfer that dependency's implementation into this package. No ownership or license is asserted over third-party dependencies.

## Local functional references

- OFF BEAT DIVERPUNK: `Assets/Scripts/Game/Scriptable Presets/Audio/GameAudioBindingData.cs` and `GameAudioManagerPreset.cs`: event tuning, playback defaults, bus routing and music controls.
- OFF BEAT DIVERPUNK: `Assets/Scripts/Editor/GameManagement Tool/Graphic/Audio/`: catalog assignment, event map, rate-limit and validation workflows.
- OFF BEAT DIVERPUNK: `FMOD/BBB_FMOD/Metadata/`: observed XML object and relationship structure for read-only catalog parsing. None of this project data is included.
- Installed FMOD public editor API signatures were inspected in `Settings.cs`, `EditorEventRef.cs`, `EditorParamRef.cs`, `EditorBankRef.cs`, `EventManager.cs` and `EditorUtils.cs`. No SDK implementation is copied.

## Official API references

- [FMOD Unity user guide](https://www.fmod.com/docs/2.03/unity/user-guide.html)
- [FMOD Event Browser](https://www.fmod.com/docs/2.03/unity/event-browser.html)
- [FMOD Unity scripting API](https://www.fmod.com/docs/2.03/unity/api.html)
- [Unity custom packages](https://docs.unity3d.com/6000.0/Documentation/Manual/CustomPackages.html)
- [Unity current assembly enumeration](https://docs.unity.com/en-us/engine/6000.7/script-reference/unityengine/assemblies/currentassemblies/getloadedassemblies): public API, also verified in the installed Unity 6000.6.0f1 API documentation. Used on Unity 6000.5 and newer.
- [Unity TypeCache.GetTypesDerivedFrom](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/TypeCache.GetTypesDerivedFrom.html): native editor type lookup for earlier supported Unity 6 versions. No AppDomain assembly enumeration is used.

Studio metadata parsing is based on the locally observed XML structure, not a promise of compatibility with every future Studio serialization version. The official bank cache supplies additional details when available. The optional reflection adapter exists only in the Editor assembly and accesses public members. Runtime audio dispatch is deliberately left to the consuming project.
